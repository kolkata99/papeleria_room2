package co.edu.unab.apirest_papeleria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApirestPapeleriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApirestPapeleriaApplication.class, args);
	}

}
