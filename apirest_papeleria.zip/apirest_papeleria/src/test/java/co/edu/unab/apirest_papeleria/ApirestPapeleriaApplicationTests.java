package co.edu.unab.apirest_papeleria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApirestPapeleriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
